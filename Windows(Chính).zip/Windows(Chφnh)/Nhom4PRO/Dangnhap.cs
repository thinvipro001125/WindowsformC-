﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Configuration;
using System.Data.SqlClient;

namespace Nhom4PRO
{
    public partial class Dangnhap : Form
    {
        public Dangnhap()
        {
            InitializeComponent();
        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {
        
        }

        private void Form1_Load(object sender, EventArgs e)
        {
          
        }

        private void btdn_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection(@"Data Source=DESKTOP-22FV7V6\SQLEXPRESS;Initial Catalog=QL_MN;Integrated Security=True");
            try
            {
                con.Open();
                string tk = txtk.Text;
                string mk = txtmk.Text;
                string sql = "select *from Dangnhap where Taikhoan='" + tk + "'and Matkhau='" + mk + "'";
                SqlCommand command = new SqlCommand(sql, con);
                SqlDataReader dta = command.ExecuteReader();
                if (dta.Read() == true)
                {
                    MessageBox.Show("Đăng nhập thành công", "Thông báo");
                    giaodienchinh t = new giaodienchinh();
                    t.Show();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Sai tài khoản hoặc mật khẩu", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }    
        }

       
        private void btthoat_Click(object sender, EventArgs e)
        {
           DialogResult d;
           d =  MessageBox.Show("Bạn có thực sự muốn thoát ???", "thông báo", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
           if(d==DialogResult.Yes)
            {
                Close();
            }    
        }
    }
}
