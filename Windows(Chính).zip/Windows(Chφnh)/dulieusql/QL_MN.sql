﻿create database QL_MN
---------------
Go
use QL_MN

   
 Create Table Hocsinh
(
	MaHs int not null primary key ,
	TenHs Nvarchar(30),
	Ngaysinh date,	
	TenPh Nvarchar(30),
	SdtPh int,
	Hocphi int
)
go
--2. Bảng QLGV
Create Table QLGV
(
	MaGv varchar(10) not null primary key,
	TenGv nvarchar(30),
	Ngaysinh date,
	Email nvarchar(30),
	Sdt int,
	Luong int
)
--3. Bảng QLLH
Create Table QLLH
(
	Malop nvarchar(4) not null primary key,
	Tenlop nvarchar(20),
	Gvcn nvarchar(30),
	Siso int,
	Thoigianmolop date
	
	
)
--4. Bảng CSVC
Create Table CSVC
(
	TenSp nvarchar(30) not null primary key,
	Soluong int
) 	


--II. Nhập dữ liệu cho các bảng theo mẫu
--Bảng Khoa:
Insert into Hocsinh  
values('1',N'Tạ Thành Lâm','2015-11-01',N'Tạ Thành Tặc','0323323212','4000000')
Insert into Hocsinh   
values('2',N'Hoàng Minh Minh','2015-11-22',N'Hoàng Bình Bình','0324857384','6000000')
Insert into Hocsinh   
values('3',N'Lê Thị Hoa','2015-03-12',N'Lê Thị Hồng','0990789212','4000000')
Insert into Hocsinh   
values('4',N'Lê Bá Hải','2015-12-12',N'Lê Bá Tặc','0909081312','4000000')
Insert into Hocsinh   
values('5',N'Phạm Thị Hoa','2015-01-09',N'Phạm Thị Mai','0435867295','6000000')
Insert into Hocsinh   
values('6',N'Lê Vĩnh Phúc','2015-01-04',N'Lê Vĩnh Lợi','0234212340','4000000')
Insert into Hocsinh   
values('7',N'Phạm Văn Hùng','2015-09-04',N'Phạm Văn Vương','0919095413','4000000')
Insert into Hocsinh   
values('8',N'Nguyễn Thanh Tâm','2015-05-07',N'Nguyễn Thanh Tịnh','096899031','6000000')
Insert into Hocsinh   
values('9',N'Đỗ Minh Hoàng','2015-09-11',N'Đỗ Minh Hôn','096879912','4000000')
Insert into Hocsinh   
values('10',N'Trần Thị Dung','2015-10-01',N'Trần Thị Thứ','034075634','4000000')
Insert into Hocsinh   
values('11',N'Lê Văn Lợi','2015-01-12',N'lê Văn Lộc','0348764553','4000000')
Insert into Hocsinh   
values('12',N'Đặng Trung Tiến','2015-12-22',N'Đặng Trung Lên','0362394398','4000000')
Insert into Hocsinh   
values('13',N'Nguyễn Văn Hùng','2015-12-12',N'Nguyễn Văn Vương','0347668283','6000000')
Insert into Hocsinh   
values('14',N'Đặng Trung Quân','2015-11-22',N'Đặng Trung Minh','0362394698','4000000')
Insert into Hocsinh   
values('15',N'Nguyễn Văn Tá','2015-12-25',N'Nguyễn Văn Thượng','0347668273','6000000')
Insert into Hocsinh  
values('16',N'Tạ Thành Hùng','2015-11-01',N'Tạ Thành Ngố','0323323212','4000000')
Insert into Hocsinh   
values('17',N'Hoàng Minh Bình','2015-11-22',N'Hoàng Bình Minh','0324857384','6000000')
Insert into Hocsinh   
values('18',N'Lê Thị Hồng','2015-03-12',N'Lê Thị Hoa','0990789212','4000000')
Insert into Hocsinh   
values('19',N'Lê Bá Tặc','2015-12-12',N'Lê Bá Hải','0909081312','4000000')
Insert into Hocsinh   
values('20',N'Phạm Thị Mai','2015-01-09',N'Phạm Thị Hoa','0435867295','6000000')
Insert into Hocsinh   
values('21',N'Lê Vĩnh Hằng','2015-01-04',N'Lê Vĩnh Nga','0234212340','4000000')
Insert into Hocsinh   
values('22',N'Phạm Văn Hí','2015-09-04',N'Phạm Văn Vĩ','0919095413','4000000')
Insert into Hocsinh   
values('23',N'Nguyễn Thanh Tính','2015-05-07',N'Nguyễn Thanh Tình','096899031','6000000')
Insert into Hocsinh   
values('24',N'Đỗ Minh Hoà','2015-09-11',N'Đỗ Minh Hôn','096879912','4000000')
Insert into Hocsinh   
values('25',N'Trần Thị Dinh','2015-10-01',N'Trần Thị Thứ Ba','034075634','4000000')
Insert into Hocsinh   
values('26',N'Lê Văn Hại','2015-01-12',N'lê Văn Lộc','0348764553','4000000')
Insert into Hocsinh   
values('27',N'Đặng Trung Tin','2015-12-22',N'Đặng Trung Lền','0362394398','4000000')
Insert into Hocsinh   
values('28',N'Nguyễn Văn Hù','2015-12-12',N'Nguyễn Văn Vinh','0347668283','6000000')
Insert into Hocsinh   
values('29',N'Đặng Trung Quân','2015-11-22',N'Đặng Trung Vĩnh','0362394698','4000000')
Insert into Hocsinh   
values('30',N'Nguyễn Văn Tà','2015-12-25',N'Nguyễn Văn Đạo','0347668273','6000000')
Insert into Hocsinh  
values('31',N'Tạ Thành Lâm Tặc','2015-11-01',N'Tạ Thành Tặc Lâm','0323323212','4000000')
Insert into Hocsinh   
values('32',N'Hoàng Minh Trị','2015-11-22',N'Hoàng Bình Thiên','0324857384','6000000')
Insert into Hocsinh   
values('33',N'Lê Thị Hoa Hồng','2015-03-12',N'Lê Thị Hồng Hoa','0990789212','4000000')
Insert into Hocsinh   
values('34',N'Lê Bá Hải Dớ','2015-12-12',N'Lê Bá Đạo','0909081312','4000000')
Insert into Hocsinh   
values('35',N'Phạm Thị Hoa Hướng Dương','2015-01-09',N'Phạm Thị Mai Táng','0435867295','6000000')
Insert into Hocsinh   
values('36',N'Lê Vĩnh Phúc Hậu','2015-01-04',N'Lê Vĩnh Lợi Ích','0234212340','4000000')
Insert into Hocsinh   
values('37',N'Phạm Văn Hùng Ngố','2015-09-04',N'Phạm Văn Vương Vãi','0919095413','4000000')
Insert into Hocsinh   
values('38',N'Nguyễn Thanh Tâm Tịnh','2015-05-07',N'Nguyễn Thanh Tịnh Tâm','096899031','6000000')
Insert into Hocsinh   
values('39',N'Đỗ Minh Hoàng Vũ','2015-09-11',N'Đỗ Minh Hôn Hít','096879912','4000000')
Insert into Hocsinh   
values('40',N'Trần Thị Dung Hạnh','2015-10-01',N'Trần Thị Thứ Mất Dạy','034075634','4000000')
Insert into Hocsinh   
values('41',N'Lê Văn Lợi Hàm','2015-01-12',N'lê Văn Lộc Đãng','0348764553','4000000')
Insert into Hocsinh   
values('42',N'Đặng Trung Tiến Vua','2015-12-22',N'Đặng Trung Lên Đỉnh','0362394398','4000000')
Insert into Hocsinh   
values('43',N'Nguyễn Văn Hùng Hực','2015-12-12',N'Nguyễn Văn Vương Vấn','0347668283','6000000')
Insert into Hocsinh   
values('44',N'Đặng Trung Quân Đội','2015-11-22',N'Đặng Trung Minh Trĩ','0362394698','4000000')
Insert into Hocsinh   
values('45',N'Nguyễn Văn Tá Điền','2015-12-25',N'Nguyễn Văn Thượng Úy','0347668273','6000000')
Insert into Hocsinh  
values('46',N'Tạ Thành Hùng Vĩ','2015-11-01',N'Tạ Thành Ngu','0323323212','4000000')
Insert into Hocsinh   
values('47',N'Hoàng Minh Bình Định','2015-11-22',N'Hoàng Bình Minh Anh','0324857384','6000000')
Insert into Hocsinh   
values('48',N'Lê Thị Hồng Nhạt','2015-03-12',N'Lê Thị Hoa Đậm','0990789212','4000000')
Insert into Hocsinh   
values('49',N'Lê Bá Tặc Chuỗi','2015-12-12',N'Lê Bá Hải Dóng','0909081312','4000000')
Insert into Hocsinh   
values('50',N'Phạm Thị Mai Tính','2015-01-09',N'Phạm Thị Hoa Đào','0435867295','6000000')
Insert into Hocsinh   
values('51',N'Lê Vĩnh Hằng Ngã','2015-01-04',N'Lê Vĩnh Nga Ngố','0234212340','4000000')
Insert into Hocsinh   
values('52',N'Phạm Văn Hình','2015-09-04',N'Phạm Văn Sự','0919095413','4000000')
Insert into Hocsinh   
values('53',N'Nguyễn Thanh Tình','2015-05-07',N'Nguyễn Thanh Tình Yêu','096899031','6000000')
Insert into Hocsinh   
values('54',N'Đỗ Minh Hoà Bình','2015-09-11',N'Đỗ Minh Hôn Phu','096879912','4000000')
Insert into Hocsinh   
values('55',N'Trần Thị Dinh Thự','2015-10-01',N'Trần Thị Biệt Thự','034075634','4000000')
Insert into Hocsinh   
values('56',N'Lê Văn Hại Lợi','2015-01-12',N'lê Văn Lộc Cộc','0348764553','4000000')
Insert into Hocsinh   
values('57',N'Đặng Trung Tình','2015-12-22',N'Đặng Trung Lền','0362394398','4000000')
Insert into Hocsinh   
values('58',N'Nguyễn Văn Hù','2015-12-12',N'Nguyễn Văn Vinh','0347668283','6000000')
Insert into Hocsinh   
values('59',N'Nguyễn Văn Tà','2015-12-25',N'Nguyễn Văn Đạo','0347668273','6000000')
Insert into Hocsinh   
values('60',N'Đỗ Minh Hoà Thuận','2015-09-11',N'Đỗ Minh Hôn Phu','096879912','4000000')
Insert into Hocsinh   
values('61',N'Trần Thị Dinh ','2015-10-01',N'Trần Thị Biệt Thự','034075634','4000000')
Insert into Hocsinh   
values('62',N'Lê Văn Hại Ăn','2015-01-12',N'lê Văn Lộc ','0348764553','4000000')
Insert into Hocsinh   
values('63',N'Đặng Trung Tình Yêu','2015-12-22',N'Đặng Trung Lền','0362394398','4000000')
Insert into Hocsinh   
values('64',N'Nguyễn Văn Hù Dọa','2015-12-12',N'Nguyễn Văn Vinh','0347668283','6000000')
Insert into Hocsinh   
values('65',N'Đặng Trung Quân Dân','2015-11-22',N'Đặng Trung Vĩnh','0362394698','4000000')
Insert into Hocsinh   
values('66',N'Nguyễn Văn Tà Đạo','2015-12-25',N'Nguyễn Văn Đạo','0347668273','6000000')
Insert into Hocsinh   
values('67',N'Nguyễn Thị Mẫn Nghi','2015-12-25',N'Nguyễn Thành Nhân','0347668273','6000000')
--Bảng QLGV:
Insert into QLGV  
values('A202',N'Tạ Thành Hạnh','2015-11-01',N'hanh@gmail.com','0323323212','4000000')
Insert into QLGV   
values('A203',N'Hoàng Minh Tinh','2015-11-22',N'tinh@gmail.com','0324857384','4000000')
Insert into QLGV   
values('A204',N'Lê Thị Hồng','2015-03-12',N'hong@gmail.com','0990789212','4000000')
Insert into QLGV   
values('B101',N'Lê Bá Năng','2015-12-12',N'nang@gmail.com','090901312','4000000')
Insert into QLGV   
values('B102',N'Phạm Thị Hoa','2015-01-09',N'hoa@gmail.com','0435867295','4000000')
Insert into QLGV   
values('B103',N'Lê Thị Thu','2015-01-04',N'thu@gmail.com','0234212340','4000000')
Insert into QLGV   
values('B104',N'Phạm Ngọc Nhã','2015-09-04',N'nha@gmail.com','0919095413','4000000')
Insert into QLGV   
values('C102',N'Phạm Thị Nhi','2015-01-09',N'nhi@gmail.com','0435867295','4000000')
Insert into QLGV   
values('C103',N'Lê Thị Trinh','2015-01-04',N'trinh@gmail.com','0234212340','4000000')
Insert into QLGV   
values('C104',N'Phạm Ngọc Trang','2015-09-04',N'trang@gmail.com','0919095413','4000000')   

--Bảng Lop:
Insert into QLLH  
values('L202',N'Lớp cá con',N'Tạ Thành Hạnh,Phạm Ngọc Trang','15','2020-11-01')
Insert into QLLH   
values('L203',N'Lớp mèo con',N'Hoàng Minh Tinh,Lê Thị Trinh','15','2020-11-01')
Insert into QLLH   
values('L204',N'Lớp heo con',N'Lê Thị Hồng,Phạm Thị Nhi','15','2020-11-01')
Insert into QLLH   
values('L101',N'Lớp gà con',N'Lê Bá Năng,Phạm Ngọc Nhã','15','2020-11-12')
Insert into QLLH   
values('L102',N'Lớp voi con',N'Phạm Thị Hoa,Lê Thị Thu','15','2020-10-09')
--Bảng CSVC:
Insert into CSVC   
values(N'Ghế',200)
Insert into CSVC   
values(N'Bàn',100)
Insert into CSVC   
values(N'Đồng phục',100)
Insert into CSVC   
values(N'Thiết bị sân chơi',6)
Insert into CSVC   
values(N'Dụng cụ văn nghệ',30)
