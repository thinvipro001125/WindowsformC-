﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Configuration;
using System.Data.SqlClient;

namespace Nhom4PRO
{
    public partial class quanlyhocsinh : Form
    {
        SqlConnection connection;
        SqlCommand command;
        string str = @"Data Source=DESKTOP-22FV7V6\SQLEXPRESS;Initial Catalog=QL_MN;Integrated Security=True";
        SqlDataAdapter adapter = new SqlDataAdapter();
        DataTable table = new DataTable();
        void loaddata()
        {
            command = connection.CreateCommand();
            command.CommandText = "select * from Hocsinh";
            adapter.SelectCommand = command;
            table.Clear();
            adapter.Fill(table);
            dshocsinh.DataSource = table;
        }
        public quanlyhocsinh()
        {
            InitializeComponent();
        }
        
        private void quanlyhocsinh_Load(object sender, EventArgs e)
        {
            connection = new SqlConnection(str);
            connection.Open();
            loaddata();
        }

        private void dshocsinh_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            dshocsinh.ReadOnly = true;
            int i;

            i = dshocsinh.CurrentRow.Index;
            txtMahs.Text = dshocsinh.Rows[i].Cells[0].Value.ToString();
            txtTenhs.Text = dshocsinh.Rows[i].Cells[1].Value.ToString();
            datengaysinh.Text = dshocsinh.Rows[i].Cells[2].Value.ToString();
            txtTenph.Text = dshocsinh.Rows[i].Cells[3].Value.ToString();
            txtSdtph.Text = dshocsinh.Rows[i].Cells[4].Value.ToString();
            txtHocphi.Text = dshocsinh.Rows[i].Cells[5].Value.ToString();
            
        }

        private void btThem_Click(object sender, EventArgs e)
        {
            command = connection.CreateCommand();
            command.CommandText = "insert into Hocsinh values('"+txtMahs.Text+ "','" + txtTenhs.Text + "','" +datengaysinh.Text + "','" + txtTenph.Text + "','" + txtSdtph.Text + "','" + txtHocphi.Text + "')";
            command.ExecuteNonQuery();
            loaddata();

                
        }

        private void btXoa_Click(object sender, EventArgs e)
        {
            DialogResult d;
            d = MessageBox.Show("Bạn có thực sự muốn xóa ???", "thông báo", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (d == DialogResult.Yes)
            {
                command = connection.CreateCommand();
                command.CommandText = "delete Hocsinh where MaHs='" + txtMahs.Text + "'";
                command.ExecuteNonQuery();
                loaddata();
            }
            
        }

        private void btSua_Click(object sender, EventArgs e)
        {
            command = connection.CreateCommand();
            command.CommandText = "update Hocsinh set TenHs = N'" + txtTenhs.Text + "', Ngaysinh = '" + datengaysinh.Text + "', TenPh = N'" + txtTenph.Text + "', SdtPh = '" + txtSdtph.Text + "' , Hocphi = '" + txtHocphi.Text + "' where MaHs = '" + txtMahs.Text+"'";
            command.ExecuteNonQuery();
            loaddata();
        }

       
    }
}
