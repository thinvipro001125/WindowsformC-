﻿namespace Nhom4PRO
{
    partial class quanlyhocsinh
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(quanlyhocsinh));
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.datengaysinh = new System.Windows.Forms.DateTimePicker();
            this.txtHocphi = new System.Windows.Forms.TextBox();
            this.txtSdtph = new System.Windows.Forms.TextBox();
            this.txtTenph = new System.Windows.Forms.TextBox();
            this.txtTenhs = new System.Windows.Forms.TextBox();
            this.txtMahs = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.labal1 = new System.Windows.Forms.Label();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.btXoa = new System.Windows.Forms.Button();
            this.btSua = new System.Windows.Forms.Button();
            this.btThem = new System.Windows.Forms.Button();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.dshocsinh = new System.Windows.Forms.DataGridView();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dshocsinh)).BeginInit();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.BackColor = System.Drawing.Color.Transparent;
            this.groupBox1.Controls.Add(this.datengaysinh);
            this.groupBox1.Controls.Add(this.txtHocphi);
            this.groupBox1.Controls.Add(this.txtSdtph);
            this.groupBox1.Controls.Add(this.txtTenph);
            this.groupBox1.Controls.Add(this.txtTenhs);
            this.groupBox1.Controls.Add(this.txtMahs);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.labal1);
            this.groupBox1.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox1.Location = new System.Drawing.Point(18, 18);
            this.groupBox1.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Padding = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.groupBox1.Size = new System.Drawing.Size(873, 460);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "THÔNG TIN HỌC SINH";
            // 
            // datengaysinh
            // 
            this.datengaysinh.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.datengaysinh.Location = new System.Drawing.Point(277, 173);
            this.datengaysinh.Name = "datengaysinh";
            this.datengaysinh.Size = new System.Drawing.Size(134, 30);
            this.datengaysinh.TabIndex = 2;
            // 
            // txtHocphi
            // 
            this.txtHocphi.ForeColor = System.Drawing.SystemColors.InfoText;
            this.txtHocphi.Location = new System.Drawing.Point(272, 381);
            this.txtHocphi.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.txtHocphi.Name = "txtHocphi";
            this.txtHocphi.Size = new System.Drawing.Size(516, 30);
            this.txtHocphi.TabIndex = 5;
            // 
            // txtSdtph
            // 
            this.txtSdtph.ForeColor = System.Drawing.SystemColors.InfoText;
            this.txtSdtph.Location = new System.Drawing.Point(272, 311);
            this.txtSdtph.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.txtSdtph.Name = "txtSdtph";
            this.txtSdtph.Size = new System.Drawing.Size(516, 30);
            this.txtSdtph.TabIndex = 4;
            // 
            // txtTenph
            // 
            this.txtTenph.ForeColor = System.Drawing.SystemColors.InfoText;
            this.txtTenph.Location = new System.Drawing.Point(272, 243);
            this.txtTenph.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.txtTenph.Name = "txtTenph";
            this.txtTenph.Size = new System.Drawing.Size(516, 30);
            this.txtTenph.TabIndex = 3;
            // 
            // txtTenhs
            // 
            this.txtTenhs.ForeColor = System.Drawing.SystemColors.InfoText;
            this.txtTenhs.Location = new System.Drawing.Point(272, 109);
            this.txtTenhs.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.txtTenhs.Name = "txtTenhs";
            this.txtTenhs.Size = new System.Drawing.Size(516, 30);
            this.txtTenhs.TabIndex = 1;
            // 
            // txtMahs
            // 
            this.txtMahs.ForeColor = System.Drawing.SystemColors.InfoText;
            this.txtMahs.Location = new System.Drawing.Point(272, 43);
            this.txtMahs.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.txtMahs.Name = "txtMahs";
            this.txtMahs.Size = new System.Drawing.Size(516, 30);
            this.txtMahs.TabIndex = 0;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(34, 315);
            this.label5.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(208, 23);
            this.label5.TabIndex = 0;
            this.label5.Text = "Số điện thoại phụ huynh";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(34, 248);
            this.label4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(202, 23);
            this.label4.TabIndex = 0;
            this.label4.Text = "Tên phụ huynh đại diện";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(34, 180);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(92, 23);
            this.label3.TabIndex = 0;
            this.label3.Text = "Ngày sinh";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(34, 114);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(114, 23);
            this.label2.TabIndex = 0;
            this.label2.Text = "Tên học sinh";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(34, 388);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(170, 23);
            this.label1.TabIndex = 0;
            this.label1.Text = "Thanh toán học phí";
            // 
            // labal1
            // 
            this.labal1.AutoSize = true;
            this.labal1.Location = new System.Drawing.Point(34, 48);
            this.labal1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.labal1.Name = "labal1";
            this.labal1.Size = new System.Drawing.Size(110, 23);
            this.labal1.TabIndex = 0;
            this.labal1.Text = "Mã học sinh";
            // 
            // groupBox2
            // 
            this.groupBox2.BackColor = System.Drawing.Color.Transparent;
            this.groupBox2.Controls.Add(this.btXoa);
            this.groupBox2.Controls.Add(this.btSua);
            this.groupBox2.Controls.Add(this.btThem);
            this.groupBox2.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox2.Location = new System.Drawing.Point(899, 18);
            this.groupBox2.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Padding = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.groupBox2.Size = new System.Drawing.Size(283, 435);
            this.groupBox2.TabIndex = 0;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "TÁC VỤ";
            // 
            // btXoa
            // 
            this.btXoa.BackColor = System.Drawing.Color.PowderBlue;
            this.btXoa.Location = new System.Drawing.Point(76, 315);
            this.btXoa.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btXoa.Name = "btXoa";
            this.btXoa.Size = new System.Drawing.Size(142, 63);
            this.btXoa.TabIndex = 3;
            this.btXoa.Text = "XÓA";
            this.btXoa.UseVisualStyleBackColor = false;
            this.btXoa.Click += new System.EventHandler(this.btXoa_Click);
            // 
            // btSua
            // 
            this.btSua.BackColor = System.Drawing.Color.PowderBlue;
            this.btSua.Location = new System.Drawing.Point(76, 192);
            this.btSua.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btSua.Name = "btSua";
            this.btSua.Size = new System.Drawing.Size(142, 52);
            this.btSua.TabIndex = 3;
            this.btSua.Text = "SỬA";
            this.btSua.UseVisualStyleBackColor = false;
            this.btSua.Click += new System.EventHandler(this.btSua_Click);
            // 
            // btThem
            // 
            this.btThem.BackColor = System.Drawing.Color.PowderBlue;
            this.btThem.Location = new System.Drawing.Point(76, 48);
            this.btThem.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btThem.Name = "btThem";
            this.btThem.Size = new System.Drawing.Size(142, 58);
            this.btThem.TabIndex = 3;
            this.btThem.Text = "THÊM";
            this.btThem.UseVisualStyleBackColor = false;
            this.btThem.Click += new System.EventHandler(this.btThem_Click);
            // 
            // groupBox3
            // 
            this.groupBox3.BackColor = System.Drawing.Color.Transparent;
            this.groupBox3.Controls.Add(this.dshocsinh);
            this.groupBox3.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox3.Location = new System.Drawing.Point(18, 488);
            this.groupBox3.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Padding = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.groupBox3.Size = new System.Drawing.Size(1164, 465);
            this.groupBox3.TabIndex = 0;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "DANH SÁCH HỌC SINH";
            // 
            // dshocsinh
            // 
            this.dshocsinh.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dshocsinh.Location = new System.Drawing.Point(25, 29);
            this.dshocsinh.Name = "dshocsinh";
            this.dshocsinh.RowHeadersWidth = 62;
            this.dshocsinh.RowTemplate.Height = 28;
            this.dshocsinh.Size = new System.Drawing.Size(1082, 181);
            this.dshocsinh.TabIndex = 0;
            this.dshocsinh.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dshocsinh_CellContentClick);
            // 
            // quanlyhocsinh
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(1200, 971);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.groupBox1);
            this.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Name = "quanlyhocsinh";
            this.Text = "Quản lý học sinh";
            this.Load += new System.EventHandler(this.quanlyhocsinh_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox3.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dshocsinh)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label labal1;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.TextBox txtMahs;
        private System.Windows.Forms.TextBox txtTenhs;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtSdtph;
        private System.Windows.Forms.TextBox txtTenph;
        private System.Windows.Forms.Button btXoa;
        private System.Windows.Forms.Button btSua;
        private System.Windows.Forms.Button btThem;
        private System.Windows.Forms.TextBox txtHocphi;
        private System.Windows.Forms.DataGridView dshocsinh;
        private System.Windows.Forms.DateTimePicker datengaysinh;
    }
}