﻿namespace Nhom4PRO
{
    partial class quanlytrochoi
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btn_rollDice = new System.Windows.Forms.Button();
            this.lbl_dice = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // btn_rollDice
            // 
            this.btn_rollDice.Location = new System.Drawing.Point(466, 543);
            this.btn_rollDice.Name = "btn_rollDice";
            this.btn_rollDice.Size = new System.Drawing.Size(210, 53);
            this.btn_rollDice.TabIndex = 1;
            this.btn_rollDice.Text = "Chuyển";
            this.btn_rollDice.UseVisualStyleBackColor = true;
            this.btn_rollDice.Click += new System.EventHandler(this.btn_rollDice_Click);
            // 
            // lbl_dice
            // 
            this.lbl_dice.ForeColor = System.Drawing.SystemColors.ActiveCaption;
            this.lbl_dice.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.lbl_dice.Location = new System.Drawing.Point(25, 9);
            this.lbl_dice.Margin = new System.Windows.Forms.Padding(0);
            this.lbl_dice.Name = "lbl_dice";
            this.lbl_dice.Size = new System.Drawing.Size(1000, 522);
            this.lbl_dice.TabIndex = 10;
            this.lbl_dice.Click += new System.EventHandler(this.lbl_dice_Click);
            // 
            // quanlytrochoi
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.ClientSize = new System.Drawing.Size(1132, 598);
            this.Controls.Add(this.btn_rollDice);
            this.Controls.Add(this.lbl_dice);
            this.Name = "quanlytrochoi";
            this.Text = "quanlytrochoi";
            this.TopMost = true;
            this.Load += new System.EventHandler(this.quanlytrochoi_Load);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label lbl_dice;
        private System.Windows.Forms.Button btn_rollDice;
    }
}