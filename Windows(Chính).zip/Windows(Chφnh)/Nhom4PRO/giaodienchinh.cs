﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Nhom4PRO
{
    public partial class giaodienchinh : Form
    {
        public giaodienchinh()
        {
            InitializeComponent();
        }

        

        private void đăngXuấtToolStripMenuItem_Click(object sender, EventArgs e)
        {
            DialogResult d;
            d = MessageBox.Show("Bạn có thực sự muốn đăng xuất ???", "thông báo", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (d == DialogResult.Yes)
            {
                Close();
            }
        }

        private void quảnLýToolStripMenuItem_Click(object sender, EventArgs e)
        {
            quanlyhocsinh qlhs = new quanlyhocsinh();
            qlhs.Show();
        }

        private void quảnLýGiáoViênToolStripMenuItem_Click(object sender, EventArgs e)
        {
            quanlygiaovien qlgv = new quanlygiaovien();
            qlgv.Show();
        }

        private void quảnLýLớpHọcToolStripMenuItem_Click(object sender, EventArgs e)
        {
            quanlylophoc qllh = new quanlylophoc();
            qllh.Show();
        }

        private void giaodienchinh_Load(object sender, EventArgs e)
        {

        }

        private void tròChơiToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            quanlytrochoi qltc = new quanlytrochoi();
            qltc.Show();
        }

        private void frm_qlcsvc_Click(object sender, EventArgs e)
        {
            quanlycosovatchat qlcsvc = new quanlycosovatchat();
            qlcsvc.Show();
        }
    }
}
