﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Configuration;
using System.Data.SqlClient;


namespace Nhom4PRO
{
    public partial class quanlycosovatchat : Form
    {
        SqlConnection connection;
        SqlCommand command;
        string str = @"Data Source=DESKTOP-22FV7V6\SQLEXPRESS;Initial Catalog=QL_MN;Integrated Security=True";
        SqlDataAdapter adapter = new SqlDataAdapter();
        DataTable table = new DataTable();
        void loaddata()
        {
            command = connection.CreateCommand();
            command.CommandText = "select * from CSVC";
            adapter.SelectCommand = command;
            table.Clear();
            adapter.Fill(table);
            dtcsvc.DataSource = table;
        }
        public quanlycosovatchat()
        {
            InitializeComponent();
        }

        private void quanlycosovatchat_Load(object sender, EventArgs e)
        {
            connection = new SqlConnection(str);
            connection.Open();
            loaddata();
        }

        private void dtcsvc_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
           dtcsvc.ReadOnly = true;
            int i;

            i = dtcsvc.CurrentRow.Index;
            txtSanpham.Text = dtcsvc.Rows[i].Cells[0].Value.ToString();
            txtSoluong.Text = dtcsvc.Rows[i].Cells[1].Value.ToString(); 

        }

        private void btThem_Click(object sender, EventArgs e)
        {
            command = connection.CreateCommand();
            command.CommandText = "insert into CSVC values(N'" + txtSanpham.Text + "','" + txtSoluong.Text + "')";
            command.ExecuteNonQuery();
            loaddata();
        }

        private void btSua_Click(object sender, EventArgs e)
        {
            command = connection.CreateCommand();
            command.CommandText = "update CSVC set Soluong = '" + txtSoluong.Text + "', where TenSp = N'" + txtSanpham.Text + "'";
            command.ExecuteNonQuery();
            loaddata();
        }

        private void btXoa_Click(object sender, EventArgs e)
        {
            DialogResult d;
            d = MessageBox.Show("Bạn có thực sự muốn xóa ???", "thông báo", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (d == DialogResult.Yes)
            {
                command = connection.CreateCommand();
                command.CommandText = "delete CSVC where TenSp =N'" + txtSanpham.Text + "' ";
                command.ExecuteNonQuery();
                loaddata();
            }
        }

       
    }
}
