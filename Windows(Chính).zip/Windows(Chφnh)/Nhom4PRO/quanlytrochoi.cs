﻿#region using Statements 
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
#endregion
namespace Nhom4PRO
{

    public partial class quanlytrochoi : Form
    {
        #region Declaration
        Image[] diceImages;
        int[] dice;
        Random rand;
        #endregion
        #region Initialization
        public quanlytrochoi()
        {
            InitializeComponent();
        }

       
        private void quanlytrochoi_Load(object sender, EventArgs e)
        {
            diceImages = new Image[16];
            diceImages[0] = Properties.Resources._1;
            diceImages[1] = Properties.Resources._2;
            diceImages[2] = Properties.Resources._3;
            diceImages[3] = Properties.Resources._4;
            diceImages[4] = Properties.Resources._5;
            diceImages[5] = Properties.Resources._6;
            diceImages[6] = Properties.Resources._7;
            diceImages[7] = Properties.Resources._8;
            diceImages[8] = Properties.Resources._9;
            diceImages[9] = Properties.Resources._10; 
            diceImages[10] = Properties.Resources._11;
            diceImages[11] = Properties.Resources._12;
            diceImages[12] = Properties.Resources._13;
            diceImages[13] = Properties.Resources._14;
            diceImages[14] = Properties.Resources._15;
            diceImages[15] = Properties.Resources._16;
           

            dice = new int[1] { 0 };
            rand = new Random();
        }
        #endregion

        private void btn_rollDice_Click(object sender, EventArgs e)
        {
            RollDice();
        }
        private void RollDice()
        {
            for (int i = 0; i < dice.Length; i++)
                dice[i] = rand.Next(1, 15 + 1);
            lbl_dice.Image = diceImages[dice[0]];
        }

        private void lbl_dice_Click(object sender, EventArgs e)
        {

        }
    }
}
