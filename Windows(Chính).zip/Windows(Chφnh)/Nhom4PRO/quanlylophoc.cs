﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Configuration;
using System.Data.SqlClient;

namespace Nhom4PRO
{
    public partial class quanlylophoc : Form
    {
        SqlConnection connection;
        SqlCommand command;
        string str = @"Data Source=DESKTOP-22FV7V6\SQLEXPRESS;Initial Catalog=QL_MN;Integrated Security=True";
        SqlDataAdapter adapter = new SqlDataAdapter();
        DataTable table = new DataTable();
        void loaddata()
        {
            command = connection.CreateCommand();
            command.CommandText = "select * from QLLH";
            adapter.SelectCommand = command;
            table.Clear();
            adapter.Fill(table);
            dtlophoc.DataSource = table;
        }
        public quanlylophoc()
        {
            InitializeComponent();
        }

        private void quanlylophoc_Load(object sender, EventArgs e)
        {
            connection = new SqlConnection(str);
            connection.Open();
            loaddata();
        }

        private void dtlophoc_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            dtlophoc.ReadOnly = true;
            int i;

            i = dtlophoc.CurrentRow.Index;
            txtMalop.Text = dtlophoc.Rows[i].Cells[0].Value.ToString();
            txtTenlop.Text = dtlophoc.Rows[i].Cells[1].Value.ToString();
            txtGvcn.Text = dtlophoc.Rows[i].Cells[2].Value.ToString();
            txtSiso.Text = dtlophoc.Rows[i].Cells[3].Value.ToString();
            dateMolop.Text = dtlophoc.Rows[i].Cells[4].Value.ToString();
            
        }

        private void btThem_Click(object sender, EventArgs e)
        {
            command = connection.CreateCommand();
            command.CommandText = "insert into QLLH values('" + txtMalop.Text + "','" + txtTenlop.Text + "','" + txtGvcn.Text + "','" + txtSiso.Text + "','" + dateMolop.Text + "')";
            command.ExecuteNonQuery();
            loaddata();
        }

        private void btSua_Click(object sender, EventArgs e)
        {
            command = connection.CreateCommand();
            command.CommandText = "update QLLH set Tenlop = N'" + txtTenlop.Text + "', Gvcn = N'" + txtGvcn.Text + "', siso = '" + txtSiso.Text + "', Thoigianmolop = '" + dateMolop.Text + "' where Malop = '" + txtMalop.Text + "'";
            command.ExecuteNonQuery();
            loaddata();
        }

        private void btXoa_Click(object sender, EventArgs e)
        {
            DialogResult d;
            d = MessageBox.Show("Bạn có thực sự muốn xóa ???", "thông báo", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (d == DialogResult.Yes)
            {
                command = connection.CreateCommand();
                command.CommandText = "delete QLLH where Malop='" + txtMalop.Text + "'";
                command.ExecuteNonQuery();
                loaddata();
            }
        }
    }
}
