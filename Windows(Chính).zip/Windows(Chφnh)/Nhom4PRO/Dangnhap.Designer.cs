﻿namespace Nhom4PRO
{
    partial class Dangnhap
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Dangnhap));
            this.lbdn = new System.Windows.Forms.Label();
            this.lbmk = new System.Windows.Forms.Label();
            this.txtk = new System.Windows.Forms.TextBox();
            this.txtmk = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.btdn = new System.Windows.Forms.Button();
            this.btthoat = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lbdn
            // 
            this.lbdn.AutoSize = true;
            this.lbdn.BackColor = System.Drawing.Color.Transparent;
            this.lbdn.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbdn.ForeColor = System.Drawing.SystemColors.ControlText;
            this.lbdn.Location = new System.Drawing.Point(38, 118);
            this.lbdn.Name = "lbdn";
            this.lbdn.Size = new System.Drawing.Size(76, 19);
            this.lbdn.TabIndex = 0;
            this.lbdn.Text = "Tài khoản";
            this.lbdn.Click += new System.EventHandler(this.label1_Click);
            // 
            // lbmk
            // 
            this.lbmk.AutoSize = true;
            this.lbmk.BackColor = System.Drawing.Color.Transparent;
            this.lbmk.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbmk.ForeColor = System.Drawing.Color.Black;
            this.lbmk.Location = new System.Drawing.Point(36, 168);
            this.lbmk.Name = "lbmk";
            this.lbmk.Size = new System.Drawing.Size(78, 19);
            this.lbmk.TabIndex = 0;
            this.lbmk.Text = "Mật Khẩu";
            // 
            // txtk
            // 
            this.txtk.Location = new System.Drawing.Point(141, 117);
            this.txtk.Name = "txtk";
            this.txtk.Size = new System.Drawing.Size(133, 20);
            this.txtk.TabIndex = 1;
            // 
            // txtmk
            // 
            this.txtmk.Location = new System.Drawing.Point(141, 167);
            this.txtmk.Name = "txtmk";
            this.txtmk.PasswordChar = '*';
            this.txtmk.Size = new System.Drawing.Size(133, 20);
            this.txtmk.TabIndex = 2;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.Transparent;
            this.label3.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label3.Location = new System.Drawing.Point(57, 35);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(208, 44);
            this.label3.TabIndex = 0;
            this.label3.Text = "HỆ THỐNG QUẢN LÝ \r\nTRƯỜNG MẦM NON";
            this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label3.Click += new System.EventHandler(this.label3_Click);
            // 
            // btdn
            // 
            this.btdn.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.btdn.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btdn.Location = new System.Drawing.Point(23, 241);
            this.btdn.Name = "btdn";
            this.btdn.Size = new System.Drawing.Size(128, 37);
            this.btdn.TabIndex = 3;
            this.btdn.Text = "ĐĂNG NHẬP";
            this.btdn.UseVisualStyleBackColor = true;
            this.btdn.Click += new System.EventHandler(this.btdn_Click);
            // 
            // btthoat
            // 
            this.btthoat.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.btthoat.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btthoat.Location = new System.Drawing.Point(166, 241);
            this.btthoat.Name = "btthoat";
            this.btthoat.Size = new System.Drawing.Size(128, 37);
            this.btthoat.TabIndex = 4;
            this.btthoat.Text = "THOÁT";
            this.btthoat.UseVisualStyleBackColor = true;
            this.btthoat.Click += new System.EventHandler(this.btthoat_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoValidate = System.Windows.Forms.AutoValidate.EnableAllowFocusChange;
            this.BackColor = System.Drawing.Color.White;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(317, 290);
            this.Controls.Add(this.btthoat);
            this.Controls.Add(this.btdn);
            this.Controls.Add(this.txtmk);
            this.Controls.Add(this.txtk);
            this.Controls.Add(this.lbmk);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.lbdn);
            this.Name = "Form1";
            this.Text = "ĐĂNG NHẬP";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lbdn;
        private System.Windows.Forms.Label lbmk;
        private System.Windows.Forms.TextBox txtk;
        private System.Windows.Forms.TextBox txtmk;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button btdn;
        private System.Windows.Forms.Button btthoat;
    }
}

